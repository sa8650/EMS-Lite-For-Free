Option Explicit

On Error Resume Next

' Create an instance of Windows Script Host Shell
Dim WshShell, shortcut, myApp, myWorkbook, wbAlreadyOpen, wb, DesktopPath
Dim ShortcutPath, IconPath, workbookName, folderPath

Set WshShell = CreateObject("WScript.Shell")

' Get the folder path of the current script
folderPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

' Define the paths for the shortcut and icon dynamically
DesktopPath = WshShell.SpecialFolders("Desktop")
ShortcutPath = DesktopPath & "\EMSLite.lnk"
IconPath = folderPath & "\Endev5.ico"

' Create the shortcut object
Set shortcut = WshShell.CreateShortcut(ShortcutPath)
shortcut.TargetPath = WScript.ScriptFullName
shortcut.IconLocation = IconPath
shortcut.Save

' Error handling for shortcut creation
If Err.Number <> 0 Then
    MsgBox "Error saving shortcut: " & Err.Description
    WScript.Quit
End If

' Check if Excel is already running and set application object
workbookName = "EMS Lite.xlsm"
Set myApp = GetObject(, "Excel.Application")

If Err.Number <> 0 Then
    Err.Clear
    Set myApp = CreateObject("Excel.Application")
End If

If Err.Number <> 0 Then
    MsgBox "Error creating Excel application object: " & Err.Description
    WScript.Quit
End If

' Check if the workbook is already open
wbAlreadyOpen = False
For Each wb In myApp.Workbooks
    If wb.Name = workbookName Then
        wbAlreadyOpen = True
        Exit For
    End If
Next

' Open workbook if not already open
If Not wbAlreadyOpen Then
    Set myWorkbook = myApp.Workbooks.Open(folderPath & "\" & workbookName)
    If Err.Number <> 0 Then
        MsgBox "Error opening workbook: " & Err.Description
        myApp.Quit
        WScript.Quit
    End If
    ' Save and close workbook
    myWorkbook.Save
    myWorkbook.Close False
End If

' Hide Excel application and quit if it was not already open
myApp.Visible = False
If Not wbAlreadyOpen Then myApp.Quit

' Cleanup
Set myApp = Nothing
Set WshShell = Nothing

' Ensure no error messages at the end
On Error Resume Next
Err.Clear
On Error GoTo 0
WScript.Quit
